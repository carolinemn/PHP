
<script language="JavaScript" type="text/javascript">
<!-- Desenvolvida por Juliano Sales-->
function validaFormulario(tipo,nome,cpf,rg,cnpj,end,numero,bairro,cidade,cep,formulario,erro,mostra)
{		
		 var erro = document.getElementById(erro);
		 field = document.getElementById(mostra);
		 form  = document.getElementById(formulario);

		 if(tipo.value==0)
			{	
				tipo.focus();
				field.style.display="block";
				erro.innerHTML = "<font color='red'>"+"Escolha uma Razao Social"+"</font>";
				return false;
			}
	     else if(nome.value.length <8 )
			{
			    nome.focus();
			   field.style.display="block";
			   erro.innerHTML = "<font color='red'>"+"Preencha o campo nome"+"</font>";
			   return false;
			}
		else if( tipo.value==1 && cpf.value.length !=14 || valida_cpf==false )
			{
			     cpf.focus();
				 field.style.display="block";
				 erro.innerHTML = "<font color='red'>"+"Preencha o campo CPF corretamente"+"</font>";
				 return false;
			}
		else if(tipo.value==2 && cnpj.value.length!=18 || valida_cnpj==false)
			{
				cnpj.focus();
				field.style.display="block";
				erro.innerHTML = "<font color='red'>"+"Preencha o campo CNPJ corretamente"+"</font>";
				return false;
			}
		else if(tipo.value ==1 &&  rg.value.length!=9 )
			{
				rg.focus() ;
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo RG corretamente"+"</font>";
				return false;
			}
		else if(tipo.value ==1 && end.value.length <1)
			{
				end.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Endereco corretamente"+"</font>";
				return false;
			}
			else if(tipo.value==2 && end.value.length< 1)
			{
				end.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Endereco corretamente"+"</font>";
				return false;
			}
		else if(tipo.value ==1 &&  numero.value.length<1)
			{
				numero.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Numero corretamente"+"</font>";
				return false;
			}
			else if(tipo.value ==2 &&  numero.value.length<1)
			{
				numero.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Numero corretamente"+"</font>";
				return false;
			}
		else if( tipo.value ==1 && bairro.value.length<1)
			{
				bairro.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Bairro corretamente"+"</font>";
				return false;
			}
		else if(tipo.value ==1 && cidade.value.length<5)
			{
				cidade.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo "+cidade.id+" corretamente"+"</font>";
				return false;
			}
		 else if(tipo.value ==1 && cep.value.length<5)
			{
			    
				cep.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo "+cep.id+" corretamente"+"</font>";
				return false;
			}
			
			else if(tipo.value ==1 &&  numero.value.length<1)
			{
				numero.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Numero corretamente"+"</font>";
				return false;
			}
			else if(tipo.value ==2 &&  numero.value.length<1)
			{
				numero.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Numero corretamente"+"</font>";
				return false;
			}
		else if( tipo.value ==2 && bairro.value.length<1)
			{
				bairro.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo Bairro corretamente"+"</font>";
				return false;
			}
		else if(tipo.value ==2 && cidade.value.length<5)
			{
				cidade.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo "+cidade.id+" corretamente"+"</font>";
				return false;
			}
		 else if(tipo.value ==2 && cep.value.length<5)
			{
			    
				cep.focus();
				field.style.display="block";
				erro.innerHTML="<font color='red'>"+"Preencha o campo "+cep.id+" corretamente"+"</font>";
				return false;
			}
		 else
		 {
			alert("Cadastro feito com  sucesso");
			form.submit( );
		    return true;
		 }
	
};
function valida_cpf(obj)
{

		var i;
		texto = obj.value.replace("-","");
		texto2 = texto.replace(".","");
		s = texto2.replace(".","");
		var c = s.substr(0,9);

		var dv = s.substr(9,2);

		var d1 = 0;

		for (i = 0; i < 9; i++)

		{

		d1 += c.charAt(i)*(10-i);

		}

		if (d1 == 0){

		return false;

		}

		d1 = 11 - (d1 % 11);

		if (d1 > 9) d1 = 0;

		if (dv.charAt(0) != d1)

		{
		return false;

		}

		d1 *= 2;

		for (i = 0; i < 9; i++)

		{

		d1 += c.charAt(i)*(11-i);

		}

		d1 = 11 - (d1 % 11);

		if (d1 > 9) d1 = 0;

		if (dv.charAt(1) != d1)

		{

		return false;

		}

};

function valida_cnpj(cnpj) {
   var i = 0;
  var l = 0;
  var strNum = "";
  var strMul = "6543298765432";
  var character = "";
  var iValido = 1;
  var iSoma = 0;
  var strNum_base = "";
  var iLenNum_base = 0;
  var iLenMul = 0;
  var iSoma = 0;
  var strNum_base = 0;
  var iLenNum_base = 0;

  if (cnpj.value == "")
        return ("Preencha o campo CNPJ.");

  l = cnpj.length;
  for (i = 0; i < l; i++) {
        caracter = cnpj.substring(i,i+1)
        if ((caracter >= '0') && (caracter <= '9'))
           strNum = strNum + caracter;
  };

  if(strNum.length != 14)
        return ("CNPJ deve conter 14 caracteres.");

  strNum_base = strNum.substring(0,12);
  iLenNum_base = strNum_base.length - 1;
  iLenMul = strMul.length - 1;
  for(i = 0;i < 12; i++)
        iSoma = iSoma +
                        parseInt(strNum_base.substring((iLenNum_base-i),(iLenNum_base-i)+1),10) *
                        parseInt(strMul.substring((iLenMul-i),(iLenMul-i)+1),10);

  iSoma = 11 - (iSoma - Math.floor(iSoma/11) * 11);
  if(iSoma == 11 || iSoma == 10)
        iSoma = 0;

  strNum_base = strNum_base + iSoma;
  iSoma = 0;
  iLenNum_base = strNum_base.length - 1
  for(i = 0; i < 13; i++)
        iSoma = iSoma +
                        parseInt(strNum_base.substring((iLenNum_base-i),(iLenNum_base-i)+1),10) *
                        parseInt(strMul.substring((iLenMul-i),(iLenMul-i)+1),10)

  iSoma = 11 - (iSoma - Math.floor(iSoma/11) * 11);
  if(iSoma == 11 || iSoma == 10)
        iSoma = 0;
  strNum_base = strNum_base + iSoma;
  if(strNum != strNum_base)
        return ("CNPJ inv�lido.");

  return (true);
};


 function mudarTamanho(campo)
 {
	 nome = document.getElementById(campo.id).value;
	 document.getElementById(campo.id).value = nome.toUpperCase();
 };
 
function mascara_Numero(campo,leg,msg)
{
 	valor = document.getElementById(campo.id).value;
 	legenda = document.getElementById(leg);
    pos=0;
		   while(pos < valor.length && valor!="")
		   {
			   if((  valor.charCodeAt(pos)!= 144 &&  valor / valor >0))
				  	    legenda.innerHTML = "";
				   else
				   {
					   legenda.innerHTML = "<font color='red'>" + msg + "</font>";
					   return false;
					}
			  pos++;
			  
		   }
};

function tipo_Pessoa(tipo,fisica,juridica)
{

       valor = document.getElementById(tipo.id).value;
       pf = document.getElementById(fisica);
	   pj = document.getElementById(juridica);	

       if(valor=="1")
       {
  		 pf.style.display = "block";
  		 pj.style.display = "none";
    		 
       }
       else if(valor =="2")
       {
    	   pj.style.display = "block";
    	   pf.style.display="none";
       }
};
	
function mascaraData(campo)
{
  data = document.getElementById(campo.id).value;

  if(data.length < 9 && data.length ==2 || data.length == 5)
		  {
            document.getElementById(campo.id).value= data+"/";
          }
  
   else if(data.length > 10)
         {
		 	document.getElementById(campo.id).value="";
		 }	       
};

function mascaraTelefone(campo)
{
	telefone = document.getElementById(campo.id).value;
	if(telefone.length ==1 && telefone.length!="")
	{
		document.getElementById(campo.id).value ="(";
		valor2
	}
	else if(telefone.length ==3)
	{
		document.getElementById(campo.id).value =telefone+")";
		
	}
	else if(telefone.length == 8)
	{
		document.getElementById(campo.id).value=telefone+"-";
	}
	else if(telefone.length==11)
	{
		document.getElementById(campo.id).value =telefone+"-";
	}
	else
	{
		if(telefone.length==15)
		document.getElementById(campo.id).value="";
		
	}
};

function mascaraSenha(campo1,campo2,leg)
{
	legenda = document.getElementById(leg);
	
	if(campo1.value == campo2.value)
	{
		legenda.innerHTML="";
	}
	else
	{
		legenda.innerHTML="<font color='red'>"+ "Senha nao confere!"+ "</font>";
	}
};


function mascara_cpf(cpf) 
{ 
if(cpf.value.length == 3) { 
cpf.value += '.'; 
} 
if(cpf.value.length == 7) {
cpf.value += '.'; 
}
if(cpf.value.length == 11) { 
cpf.value += '-'; 
}
};

    function validaRg(numero)
{
 var numero = numero.split("");
 tamanho = numero.length;
 vetor = new Array(tamanho);

if(tamanho>=1)
{
 vetor[0] = parseInt(numero[0]) * 2; 
}
if(tamanho>=2){
 vetor[1] = parseInt(numero[1]) * 3; 
}
if(tamanho>=3){
 vetor[2] = parseInt(numero[2]) * 4; 
}
if(tamanho>=4){
 vetor[3] = parseInt(numero[3]) * 5; 
}
if(tamanho>=5){
 vetor[4] = parseInt(numero[4]) * 6; 
}
if(tamanho>=6){
 vetor[5] = parseInt(numero[5]) * 7; 
}
if(tamanho>=7){
 vetor[6] = parseInt(numero[6]) * 8; 
}
if(tamanho>=8){
 vetor[7] = parseInt(numero[7]) * 9; 
}
if(tamanho>=9){
 vetor[8] = parseInt(numero[8]) * 100; 
}

 total = 0;

if(tamanho>=1){
 total += vetor[0];
}
if(tamanho>=2){
 total += vetor[1]; 
}
if(tamanho>=3){
 total += vetor[2]; 
}
if(tamanho>=4){
 total += vetor[3]; 
}
if(tamanho>=5){
 total += vetor[4]; 
}
if(tamanho>=6){
 total += vetor[5]; 
}
if(tamanho>=7){
 total += vetor[6];
}
if(tamanho>=8){
 total += vetor[7]; 
}
if(tamanho>=9){
 total += vetor[8]; 
}


 resto = total % 11;
if(resto!=0){
	return true;
}
else{
 return false;
}

		};

			  function cancelar(form)
	  {
		  if(confirm("Deseja realmente cancelar o cadastro ?"))
		  {
		  
		   return(true);
		  }
		  else
		  {
		    form.submit();
		   return(false);
		  }
		   
	  }
		
function mascaraDescr(texto,msg)
{	 
 
 if(texto.value != 144)
{
     var legenda = document.getElementById(msg);
	 var soma =0;
	 var count=0;
	 while(count<=texto.value.length)
			{
				
		      soma=count;
			  legenda.innerHTML="<font color='blue'>"+count+"</font>";
			  
			  if(texto.value.length >= 300)
				{
				
				  legenda.innerHTML="<font color='red'>"+count+"</font>";
				  break
				}
			 count++;
			}
		
		
}
else("Preencha corretamente");
}

function limitaDigitacao(objeto, limite)
{
	if (objeto.value.length >= limite)
	{
		alert("Maximo de "+ limite + " caracteres atingido.");
		return(false);
	}
}

function oncor(btn)
		{
			document.getElementById(btn).style.backgroundColor="#ff0000";
		};
		function  outcor(btn)
		{
			document.getElementById(btn).style.color="#ffffff";
		};



</script>