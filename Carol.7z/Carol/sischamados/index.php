<?php
	error_reporting(0); // para o caso de server gratuito.
	session_id( 'sc' );
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema de Chamados em PHP</title>
	<script src="_support/bootstrap/js/jquery.min.js"></script>
	<link href="_support/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="_support/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
<?php
	include_once "./model/tecnico.php";
	include_once "./model/usuario.php";
	include_once "./model/chamado.php";

	$logged = $_SESSION[sclogin];

	if(!$logged){
		include './controller/login.php';

	}else{
		include "./view/menu.php";
		$controller = $_GET[controller];
		if(!$controller) $controller = $_POST[controller];
		if(!$controller || $controller=='login') $controller='chamados';	

		if($controller =='chamados'){
			include './controller/chamados.php';

		}elseif($controller =='usuarios'){
			include './controller/usuarios.php';

		}elseif($controller =='tecnicos'){
			include './controller/tecnicos.php';
		}
	}


?>
</body>
</html>