<form method="post" action="./?controller=login&action=logar">
	Login:<input type="text" name="login"><br>
	Senha:<input type="text" name="senha"><br>
	<input type="radio" name="role" value="usr" checked> Usuário<br>
  <input type="radio" name="role" value="tec"> Técnico<br> 
 	<input type="submit">
</form>