<div class="row">
	<div class="col-xs-6">
		<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal">Novo Chamado</button>
	</div>
	<div class="col-xs-6 text-right">
		<form method="post">
			<input type="text" name="filtro" placeholder="filtrar chamados">
			<input type="hidden" name="controller" value="chamados">
			<input type="hidden" name="action" value="filtrar">
			<input type="submit" value="Filtrar">
		</form>  	
	</div>
</div>



<br>
<table class="table">
	<thead>
		<tr>
			<th>Descrição</th>
			<th>Editar</th>
			<th>Excluir</th>
		</tr>
	</thead>
	<tbody>
		<?=$tbl?>
	</tbody>
</table>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Novo Chamado</h4>
			</div>
			<div class="modal-body">
				Por favor, insira a descrição do chamado:
				<form method="post">
					​<textarea name="descricao" rows="5" cols="70"><?=$desc?></textarea><br>
					<input type="hidden" name="id" value="<?=$id?>">
					<input type="hidden" name="controller" value="chamados">
					<input type="hidden" name="action" value="createupdate">
					<input type="submit" name="enviar">
				</form>
			</div>
		</div>
	</div>
</div>