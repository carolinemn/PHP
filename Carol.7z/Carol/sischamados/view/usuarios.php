<form method="post" action="./?controller=usuarios&action=filtrar">
	Filtrar:<input type="text" name="filtro">
	<input type="hidden" name="controller" value="usuarios">
	<input type="hidden" name="action" value="filtrar">
 	<input type="submit">
</form>
<?=$tbl?>
<br><br>
Por favor, insira o nome do usuário:
<br><br>
<form method="post" action="./?controller=usuarios&action=createupdate">
	Nome:<input type="text" name="nome" value="<?=$nome?>"><br>
	Login:<input type="text" name="login" value="<?=$login?>"><br>
	Senha:<input type="password" name="senha" value="<?=$senha?>"><br>
	<input type="hidden" name="id" value="<?=$id?>">
	<input type="hidden" name="controller" value="usuarios">
	<input type="hidden" name="action" value="createupdate">
 	<input type="submit" name="enviar">
</form>
<?=$res?>