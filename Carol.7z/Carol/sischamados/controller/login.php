<?php

	if($_POST[login]!=''){
		$tipo = $_POST[role];
		if($tipo =='usr'){
			$autenticados = usuario::search($_POST[login]);
		}else{
			$autenticados = tecnico::search($_POST[login]);
		}

		if(sizeof($autenticados)){
			$autenticado = $autenticados[0];	
			if($_POST[senha] == $autenticado->getSenha()){
				$_SESSION['sclogin'] = 1;
				$_SESSION['tipo'] = $tipo;
				$_SESSION['id'] = $autenticado->getId();
				$logged = 1;
			}
		}
	}
	
	if(!$logged){
		include "./view/login.php";
	}

?>