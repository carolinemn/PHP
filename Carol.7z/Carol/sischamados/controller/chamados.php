<?php 
	if($_POST[action]=="createupdate"){
		$chamado = new chamado();
		if($_POST[id]!='') $chamado->read($_POST[id]);
		$chamado->setDescricao($_POST[descricao]);
		$chamado->setIdTecnico(1);
		$chamado->setIdUsuario(1);
		$chamado->setStatus(1);
		if($_POST[id]!=''){
			$chamado->update();
		}else{
			$chamado->create();
		}
		
	}elseif($_GET[action]=='delete'){
		$chamado = new chamado();
		$chamado->read($_GET[id]);
		$chamado->delete();

	}elseif($_GET[action]=='edit'){
		$chamadoEdicao = new chamado();
		$chamadoEdicao->read($_GET[id]);
		$desc = $chamadoEdicao->getDescricao();
		$id = $chamadoEdicao->getId();
	}

	if($_POST[action]=="filtrar"){
		$chamados = chamado::search($_POST[filtro]);
	}else{
		$chamados = chamado::getAll();
	}
		
	if(sizeof($chamados)){
		foreach ($chamados as $chamado) {
			$tbl .= "<tr>".
			"<td>".$chamado->getDescricao()."</td>".
			"<td><a href='?controller=chamados&action=edit&id=".
			$chamado->getId()."'>Editar</a></td>".
			"<td><a href='?controller=chamados&action=delete&id=".
			$chamado->getId()."'>Excluir</a></td>".
			"</tr>";
		}
	}

	include "./view/chamados.php";
?>



