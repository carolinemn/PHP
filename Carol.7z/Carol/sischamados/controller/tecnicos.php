<?php 
	if($_POST[action]=="createupdate"){
		$tecnico = new tecnico();
		if($_POST[id]!='') $tecnico->read($_POST[id]);
		$tecnico->setNome($_POST[nome]);
		$tecnico->setLogin($_POST[login]);
		$tecnico->setSenha($_POST[senha]);
		if($_POST[id]!=''){
			$tecnico->update();
		}else{
			$tecnico->create();
		}
		$res = "Técnico salvo com sucesso!!!";

	}elseif($_GET[action]=='delete'){
		$tecnico = new tecnico();
		$tecnico->read($_GET[id]);
		$tecnico->delete();

	}elseif($_GET[action]=='edit'){
		$tecnicoEdicao = new tecnico();
		$tecnicoEdicao->read($_GET[id]);
		$nome = $tecnicoEdicao->getNome();
		$login = $tecnicoEdicao->getLogin();
		$senha = $tecnicoEdicao->getSenha();
		$id = $tecnicoEdicao->getId();
	}

	if($_POST[action]=="filtrar"){
		$tecnicos = tecnico::search($_POST[filtro]);
	}else{
		$tecnicos = tecnico::getAll();
	}
		
	if(sizeof($tecnicos)){
		foreach ($tecnicos as $tecnico) {
			$tbl .= "<p>".
			$tecnico->getNome().
			" <a href='?controller=tecnicos&action=edit&id=".
			$tecnico->getId()."'>Editar</a> ".
			"<a href='?controller=tecnicos&action=delete&id=".
			$tecnico->getId()."'>Excluir</a>".
			"</p>";
		}
	}

	include "./view/tecnicos.php";
?>



