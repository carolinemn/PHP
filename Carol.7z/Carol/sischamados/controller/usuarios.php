<?php 
	if($_POST[action]=="createupdate"){
		$usuario = new usuario();
		if($_POST[id]!='') $usuario->read($_POST[id]);
		$usuario->setNome($_POST[nome]);
		$usuario->setLogin($_POST[login]);
		$usuario->setSenha($_POST[senha]);
		if($_POST[id]!=''){
			$usuario->update();
		}else{
			$usuario->create();
		}
		$res = "Técnico salvo com sucesso!!!";

	}elseif($_GET[action]=='delete'){
		$usuario = new usuario();
		$usuario->read($_GET[id]);
		$usuario->delete();

	}elseif($_GET[action]=='edit'){
		$usuarioEdicao = new usuario();
		$usuarioEdicao->read($_GET[id]);
		$nome = $usuarioEdicao->getNome();
		$login = $usuarioEdicao->getLogin();
		$senha = $usuarioEdicao->getSenha();
		$id = $usuarioEdicao->getId();
	}

	if($_POST[action]=="filtrar"){
		$usuarios = usuario::search($_POST[filtro]);
	}else{
		$usuarios = usuario::getAll();
	}
		
	if(sizeof($usuarios)){
		foreach ($usuarios as $usuario) {
			$tbl .= "<p>".
			$usuario->getNome().
			" <a href='?controller=usuarios&action=edit&id=".
			$usuario->getId()."'>Editar</a> ".
			"<a href='?controller=usuarios&action=delete&id=".
			$usuario->getId()."'>Excluir</a>".
			"</p>";
		}
	}

	include "./view/usuarios.php";
?>



