<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light "  style="background-color: #a8f7e8;">
		<a class="navbar-brand" href="#">Escola</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="PaginaInicial.html">Login <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						Cadastros
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="CadastroAlunos.html">Cadastro de Alunos</a>
						<a class="dropdown-item" href="CadastroProfessor.html">Cadastro de Professores</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="CadastroTurma.html">Cadastro de Turma </a>
					</div>
				</li>
				<li class="nav-item">
					<a class="nav-link disabled" href="#">Chat</a>
				</li>
			</ul>

		</div>
	</nav>



	<form   action="">
		<div class="Container w-75" style="position: absolute; top:100px; left: 50%; margin-left: -500px" />
		<h2>Cadastro de Alunos</h2>
		<div class="form-group">
			<input type="text" jsf:id="id" class="form-control" placeholder="Matricula"
			readonly="readonly" />
		</div>
		<div class="form-group row">
			<label class="col-sm-2 col-form-label" >Data: </label>
			<div class="col-sm-10">
				<input type="date" jsf:id="data" name="data" class="form-control"
				placeholder="00/00/0000" >
				<f:convertDateTime pattern="yyyy-MM-dd" timeZone="GMT-3"></f:convertDateTime>
			</input>
		</div>
	</div>
	<div class="form-group row">
		<br>
		<label class="col-sm-2 col-form-label" >Nome: </label>
		<div class="col-sm-10">
			<input type="text" jsf:id="Nome" class="form-control" placeholder="Digite o Nome do Aluno"/>
		</div>
	</div>
	<div class="form-group row">
		<br>
		<label class="col-sm-2 col-form-label" >Cpf: </label>
		<div class="col-sm-10">
			<input type="text" jsf:id="Cpf" class="form-control" placeholder="Digite o Cpf do Aluno"/>
		</div>
	</div>
	<div class="form-group row">
		<br>
		<label class="col-sm-2 col-form-label" >Nome da mãe: </label>
		<div class="col-sm-10">
			<input type="text" jsf:id="nomeMae" class="form-control" placeholder="Digite o Nome da Mãe"/>
		</div>
	</div>
	<div class="form-group row">
		<br>
		<label class="col-sm-2 col-form-label" >Nome do Pai: </label>
		<div class="col-sm-10">
			<input type="text" jsf:id="nomePai" class="form-control" placeholder="Digite o Nome do Pai"/>
		</div>
	</div>
	<h2>Endereco</h2>
	<div class="form-group row">
		<br>
		<label class="col-sm-2 col-form-label" >Rua: </label>
		<div class="col-sm-6">
			<input type="text" jsf:id="rua" class="form-control" placeholder="Digite o Nome da Rua"/>
		</div>
		
		<br>
		<label class="col-sm-2 col-form-label" >Nº: </label>
		<div class="col-sm-2">
			<input type="text" jsf:id="numero" class="form-control" placeholder="numero"/>
		</div>
	</div>
	
	<div class="form-group row">
		<br>
		<label class="col-sm-2 col-form-label" >Bairro: </label>
		<div class="col-sm-10">
			<input type="text" jsf:id="bairro" class="form-control" placeholder="Digite o Bairro"/>
		</div>
	</div>
	<div class="form-group row">
		<br>
		<label class="col-sm-2 col-form-label" >Cep: </label>
		<div class="col-sm-10">
			<input type="text" jsf:id="cep" class="form-control" placeholder="Digite o Cep"/>
		</div>
	</div>


</div>
</div>
</form>
<?php

	include "C:/xampp/htdocs/Projeto/Model/Cadastrodealunos.php";

?>
</body>
</html>