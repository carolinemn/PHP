<?php
include_once "C:/xampp/htdocs/Projeto/Model/databasecore.php";

class Alunos{


	private $id = 0;
	private $nome = '';
	private $cpf = '';
	private $nomeMae = '';
	private $nomePai = '';
	private $rua = '';
	private $num = 0;
	private $bairro = '';
	private $cep = '';
	private $telefone = '';
	private $dbh = '';

	function __construct(){
		$this->dbh = dataBaseCore::getHandler();
	}

	function setId($id){
		$this->id = $id;
	}
	function getId(){
		return $this->id;
	}
	function setnome($nome){-
		$this->nome = $nome;
	}

	function getnome(){
		return $this->nome;
	}
	function setcpf($cpf){
		$this->cpf = $cpf;
	}

	function getcpf(){
		return $this->cpf;
	}
	function setnomeMae($nomeMae){
		$this->nomeMae = $nomeMae;
	}

	function getnomeMae(){
		return $this->nomeMae;
	}
	function setnomePai($nomePai){
		$this->nomePai = $nomePai;
	}

	function getnomePai(){
		return $this->nomePai;
	}
	function setrua($rua){
		$this->rua = $rua;
	}

	function getrua(){
		return $this->rua;
	}
	function setnum($num){
		$this->num = $num;
	}

	function getnum(){
		return $this->num;
	}
	function setbairro($bairro){
		$this->bairro = $bairro;
	}

	function getbairro(){
		return $this->bairro;
	}
	function setcep($cep){
		$this->cep = $cep;
	}

	function getcep(){
		return $this->cep;
	}
	function settelefone($telefone){
		$this->telefone = $telefone;
	}

	function gettelefone(){
		return $this->telefone;
	}
	function setdbh($dbh){
		$this->dbh = $dbh;
	}

	function getdbh(){
		return $this->dbh;
	}

	function create(){
		$this->dbh->exec("INSERT INTO alunos(nome,cpf,nomeMae,nomePai,rua,num,bairro,cep,telefone,senha)  VALUES ('$this->nome','$this->cpf','$this->nomeMae','$this->nomePai', '$this->rua', '$this->num', '$this->bairro', '$this->cep', '$this->telefone')");
		$lastId = $this->dbh->lastInsertId();
		$this->read($lastId);
	}

	function read($id){
		 $result = $this->dbh->query("SELECT * FROM alunos WHERE id = $id");
		 $alnArray = $result->fetchAll(PDO::FETCH_ASSOC);

		 $this->setId($alnArray[0]['id']);
		 $this->setnome($alnArray[0]['nome']);
		 $this->setcpf($alnArray[0]['cpf']);
		 $this->setnomeMae($alnArray[0]['nomeMae']);
		 $this->setnomePai($alnArray[0]['nomePai']);
		 $this->setrua($alnArray[0]['rua']);
		 $this->setnum($alnArray[0]['num']);
		 $this->setbairro($alnArray[0]['bairro']);
		 $this->setcep($alnArray[0]['cep']);
		 $this->settelefone($alnArray[0]['telefone']);

	}

	function update(){
	$this->dbh->exec("UPDATE alunos SET nome='$this->nome', cpf='$this->cpf', nomeMae='$this->nomeMae', nomePai='$this->nomePai', rua='$this->rua', num='$this->num', bairro='$this->bairro', cep='$this->cep', telefone='$this->telefone' WHERE id = $this->id");
	$this->read($this->id);
	}
		function delete(){
		$this->dbh->exec("DELETE FROM alunos WHERE id = $this->id");
		$this->id = 0; // Remover referência
	}

	static function getAll(){
		$dbh = dataBaseCore::getHandler();
		$result = $dbh->query("SELECT * FROM alunos");
		$alnArray = $result->fetchAll(PDO::FETCH_ASSOC);
		$x=0;
		foreach ($alnArray as $row) {
			$alunos = new alunos();
			$alunos->read($row[id]);
			$retorno[$x] = $alunos;
			$x++;
		}
		return $retorno;
	}

	static function search($keyword = ""){
		$dbh = dataBaseCore::getHandler();
		$result = $dbh->query("SELECT id FROM alunos WHERE nome LIKE '%$keyword%' OR login LIKE '%$keyword%'");
		$alnArray = $result->fetchAll(PDO::FETCH_ASSOC);
		$x=0;
		foreach ($alnArray as $row) {
			$alunos = new alunos();
			$alunos->read($row[id]);
			$retorno[$x] = $alunos;
			$x++;
		}
		return $retorno;
	}





}

?>