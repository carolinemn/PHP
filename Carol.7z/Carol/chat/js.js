  function getgoing(){ 
    document.frmPrincipal.location.href = "default.asp"; 
    setTimeout('getgoing()',1000); 
  } 
