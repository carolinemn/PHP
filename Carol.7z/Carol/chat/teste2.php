<?
echo rand(000,1111);






?>