<script type="text/javascript" src="ajax.js"></script>
<body onmousemove="ListaOnline();" >
<div id='atualiza' ></div>
</body>
