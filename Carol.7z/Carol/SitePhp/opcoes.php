<?php

?>  -	Cadastrar clientes<BR>
-	Gerenciar clientes

